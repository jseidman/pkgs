#ifndef _MAPREADER_
#define _MAPREADER_

#include "ream.h"
#include <iostream>
#include <vector>

using namespace std;

class MapReader {
private:
  char * storecollector;
  int32_t _position;
  int32_t _numsaved;
  SEXP code2run;
  vector<int32_t> _sizes;
public:
  MapReader(int32_t , SEXP);
  ~MapReader();
  bool readObject(int32_t);
  bool spill();
  void run_map_code();  
}


#endif
